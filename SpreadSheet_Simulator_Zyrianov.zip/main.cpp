#include "Invoker.h"

using namespace std;

int main()
{
	Invoker* invoker = new Invoker;
	invoker->Start();


	return 0;
}